'''
Дата выполнения Практической-Работы: 26-27 - ЯНВАРЯ 2024 года.
'''
'''
Практическая работа

Курс: Разработка Web-приложений на Python, с применением Фреймворка Django
Дисциплина: Основы программирования на Python

Практическая работа №27: Сетевое программирование. Библиотеки requests и aiohttp

Выполните следующие задания:

Задание №1
а) Загрузите одиночный json – объект с сайта jsonplaceholder, используя библиотеку aiohttp.
б) Сохраните его в файл.

'''
'''
Урок от 26.01.2024
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Выполнение задания: (а и б)
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
ВАРИАНТ №1
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import aiohttp
import asyncio
import json

async def download_and_save_json(url, filename):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                response.raise_for_status()
                json_data = await response.json()

                with open(filename, 'w') as file:
                    json.dump(json_data, file, indent=2)

                print(f"JSON-объект успешно загружен и сохранен в файл {filename}")

    except aiohttp.ClientError as e:
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")

async def main():
    # Укажите URL и имя файла, куда сохранить JSON
    json_url = "https://jsonplaceholder.typicode.com/users/1"
    output_filename = "output_async.json"

    # Вызов функции для загрузки и сохранения JSON
    await download_and_save_json(json_url, output_filename)

# Запуск асинхронной программы
if __name__ == "__main__":
    asyncio.run(main())
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг 1: Импорт библиотек:
'''
import aiohttp
import asyncio
import json
''''
Описание:

Импортируются необходимые библиотеки: aiohttp для асинхронных HTTP-запросов, asyncio для асинхронного 
программирования, json для работы с JSON-данными.
''''
'''
Шаг 2: Определение асинхронной функции download_and_save_json:
'''
async def download_and_save_json(url, filename):
''''
Описание:

mЭта функция асинхронная и предназначена для загрузки JSON-данных по заданному URL и сохранения их в файл.
''''
'''
Шаг 3: Блок try-except внутри функции:
'''
try:
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            response.raise_for_status()
            json_data = await response.json()

            with open(filename, 'w') as file:
                json.dump(json_data, file, indent=2)

            print(f"JSON-объект успешно загружен и сохранен в файл {filename}")
except aiohttp.ClientError as e:
    print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")
'''
Описание:

Создается асинхронная сессия с помощью aiohttp.ClientSession() для выполнения HTTP-запросов.
Выполняется асинхронный GET-запрос с использованием session.get(url).
Проверяется наличие ошибок при запросе с response.raise_for_status().
Получается JSON-данные из ответа с использованием await response.json().
Сохраняются JSON-данные в файл с использованием json.dump.
Обрабатываются и выводятся ошибки с использованием aiohttp.ClientError.
'''
'''
Шаг 4: Определение асинхронной функции main:
'''
async def main():
''''
Описание:

Эта функция предназначена для запуска основной асинхронной программы.
'''''
'''
Шаг 5: Вызов функции download_and_save_json из main:
'''
await download_and_save_json(json_url, output_filename)
'''
Вызывается ранее определенная функция download_and_save_json.
'''
'''
Шаг 6: Запуск асинхронной программы:
'''
if __name__ == "__main__":
    asyncio.run(main())
'''
Описание:

Запуск основной асинхронной программы с использованием asyncio.run(main()).
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'output_async.json'
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
{
  "id": 1,
  "name": "Leanne Graham",
  "username": "Bret",
  "email": "Sincere@april.biz",
  "address": {
    "street": "Kulas Light",
    "suite": "Apt. 556",
    "city": "Gwenborough",
    "zipcode": "92998-3874",
    "geo": {
      "lat": "-37.3159",
      "lng": "81.1496"
    }
  },
  "phone": "1-770-736-8031 x56442",
  "website": "hildegard.org",
  "company": {
    "name": "Romaguera-Crona",
    "catchPhrase": "Multi-layered client-server neural-net",
    "bs": "harness real-time e-markets"
  }
}
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Мы также можем загружать JSON-объекты с различных открытых API, которые предоставляют данные в формате JSON. 
Например, некоторые популярные открытые API, которые предоставляют JSON-данные:

1. JSONPlaceholder: 
Это фейковый онлайн-сервис для тестирования и прототипирования, который предоставляет тестовые данные в формате JSON.

    URL: https://jsonplaceholder.typicode.com

2. OpenWeatherMap API: Предоставляет информацию о погоде в формате JSON.

    URL: https://openweathermap.org/api

3. GitHub API: Предоставляет данные о репозиториях, пользователях и других аспектах GitHub.

    URL: https://developer.github.com/v3

4. REST Countries API: Предоставляет информацию о странах в формате JSON.

    URL: https://restcountries.com

Просто выберите API, которое соответствует вашим интересам, и используйте его URL для загрузки JSON-данных.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
ВАРИАНТ №2
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import aiohttp
import asyncio
import json

async def download_and_save_json(url, filename):
    try:
        async with aiohttp.ClientSession() as session, session.get(url) as response:
            response.raise_for_status()
            json_data = await response.json()

            with open(filename, 'w') as file:
                json.dump(json_data, file, indent=2)

            print(f"JSON-объект успешно загружен и сохранен в файл {filename}")

    except aiohttp.ClientError as e:
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")

async def main():
    # Укажите URL и имя файла, куда сохранить JSON
    json_url = "https://jsonplaceholder.typicode.com/users/1"
    output_filename = "output_async.json"

    # Запуск асинхронной программы
    await download_and_save_json(json_url, output_filename)

# Запуск асинхронной программы
if __name__ == "__main__":
    asyncio.run(main())
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Импорт библиотек:
'''
import aiohttp
import asyncio
import json
'''
Импортируются библиотеки для асинхронных HTTP-запросов (aiohttp), 
работы с асинхронными задачами (asyncio), и работы с JSON-данными (json).
'''
'''
Определение асинхронной функции download_and_save_json:
'''
async def download_and_save_json(url, filename):
''''
Эта функция асинхронная и предназначена для загрузки JSON-данных по заданному URL и сохранения их в файл.
''''
'''
Блок try-except внутри функции:
'''
try:
    async with aiohttp.ClientSession() as session, session.get(url) as response:
        response.raise_for_status()
        json_data = await response.json()

        with open(filename, 'w') as file:
            json.dump(json_data, file, indent=2)

        print(f"JSON-объект успешно загружен и сохранен в файл {filename}")

except aiohttp.ClientError as e:
    print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")
'''
Создается асинхронная сессия и выполняется асинхронный GET-запрос с использованием контекстного менеджера async with.
Проверяется наличие ошибок при запросе с response.raise_for_status().
Получаются JSON-данные из ответа с использованием await response.json().
Сохраняются JSON-данные в файл с использованием json.dump.
Обрабатываются и выводятся ошибки с использованием aiohttp.ClientError.
'''
'''
Определение асинхронной функции main:
'''
async def main():
''''
Эта функция предназначена для запуска основной асинхронной программы.
''''
'''
Вызов функции download_and_save_json:
'''
await download_and_save_json(json_url, output_filename)
'''
Вызывается ранее определенная функция download_and_save_json с указанным URL и именем файла.
'''
'''
Запуск асинхронной программы:
'''
if __name__ == "__main__":
    asyncio.run(main())
'''
Запуск основной асинхронной программы с использованием asyncio.run(main()).
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Оба варианта кода выполняют асинхронное скачивание JSON-данных и сохранение их в файл.
Отличие в том, как они используют асинхронные контекстные менеджеры для удобства и читаемости кода.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
