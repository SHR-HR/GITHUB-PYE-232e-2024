import requests
import json

def get_server_data(url, params = None):
    try:
        response = requests.get(url, params=params)
        data = response.json()
        return data
    except:
        pass


# for i in range(100):
url = "https://its.breaktime.kz/"
params={'user': 28}
data = get_server_data(url, params)
print(data)
# if data['code'] !=404:
    # print(data['data'])
