'''
Дата выполнения Домашней-Работы: 26-27 - ЯНВАРЯ 2024 года.
'''
'''
Домашняя работа

Курс: Разработка Web-приложений на Python, с применением Фреймворка Django
Дисциплина: Основы программирования на Python

Домашняя работа №27: Сетевое программирование. Библиотеки requests и aiohttp

Выполните следующие задания:

Задание №1
а) Загрузите массив json – объектов с сайта jsonplaceholder, используя библиотеку aiohttp.
б) Сохраните циклом каждый в отдельный файл, в одну новую папку.

'''
'''
Урок от 26.01.2024
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Выполнение задания: (а и б)
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import aiohttp
import asyncio
import json
import os

async def download_and_save_json(session, url, filename):
    try:
        # Отправляем GET-запрос по указанному URL
        async with session.get(url) as response:
            response.raise_for_status()  # Проверка наличия ошибок при запросе
            json_data = await response.json()  # Получаем JSON-данные из ответа

            # Сохраняем JSON-объект в файл
            with open(filename, 'w') as file:
                json.dump(json_data, file, indent=2)

            print(f"JSON-объект успешно загружен и сохранен в файл {filename}")

    except aiohttp.ClientError as e:
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")

async def download_and_save_all_jsons():
    # Указываем базовый URL для загрузки JSON-объектов
    json_url_base = "https://jsonplaceholder.typicode.com/posts/"
    output_folder = "json_files"  # Название папки для сохранения файлов

    # Создаем папку, если ее нет
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Создаем сессию aiohttp
    async with aiohttp.ClientSession() as session:
        # Запускаем цикл для загрузки и сохранения каждого JSON-объекта
        for post_id in range(1, 51):  # Пример: загрузим 50 JSON-объектов
            json_url = f"{json_url_base}{post_id}"
            output_filename = os.path.join(output_folder, f"post_{post_id}.json")

            # Вызываем функцию загрузки и сохранения JSON-объекта
            await download_and_save_json(session, json_url, output_filename)

# Запуск асинхронной программы
if __name__ == "__main__":
    asyncio.run(download_and_save_all_jsons())
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг №1: Импорт библиотек:
'''
import aiohttp
import asyncio
import json
import os
'''
Импорт необходимых библиотек: aiohttp для асинхронных HTTP-запросов, asyncio для работы с
асинхронными задачами, json для работы с JSON-данными и os для работы с операционной системой.
'''
'''
Шаг №2: Определение асинхронной функции download_and_save_json:
'''
async def download_and_save_json(session, url, filename):
''''
Эта функция принимает асинхронную сессию (session), URL для запроса (url) и имя файла (filename).
''''
'''
Шаг №3: Блок try-except внутри функции:
'''
try:
    async with session.get(url) as response:
        response.raise_for_status()
        json_data = await response.json()

        with open(filename, 'w') as file:
            json.dump(json_data, file, indent=2)

        print(f"JSON-объект успешно загружен и сохранен в файл {filename}")

except aiohttp.ClientError as e:
    print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")
'''
Внутри try:
Отправляется асинхронный GET-запрос по указанному URL.
Проверяется наличие ошибок при запросе с использованием response.raise_for_status().
Получаются JSON-данные из ответа с использованием await response.json().
Сохраняются JSON-данные в файл.
Выводится сообщение об успешном сохранении.

В блоке except:
Обрабатываются ошибки с помощью aiohttp.ClientError.
'''
'''
Шаг №4: Определение асинхронной функции download_and_save_all_jsons:
'''
async def download_and_save_all_jsons():
''''
Эта функция предназначена для загрузки и сохранения JSON-объектов.
''''
'''
Шаг №5: Указание базового URL и создание папки:
'''
json_url_base = "https://jsonplaceholder.typicode.com/posts/"
output_folder = "json_files"

if not os.path.exists(output_folder):
    os.makedirs(output_folder)
'''
Указывается базовый URL для загрузки JSON-объектов и создается папка для сохранения файлов, если ее нет.
'''
'''
Шаг №6: Создание сессии aiohttp:
'''
async with aiohttp.ClientSession() as session:
'''
Создается асинхронная сессия aiohttp.ClientSession().
'''
'''
Шаг №7: Цикл для загрузки и сохранения JSON-объектов:
'''
for post_id in range(1, 51):
    json_url = f"{json_url_base}{post_id}"
    output_filename = os.path.join(output_folder, f"post_{post_id}.json")

    await download_and_save_json(session, json_url, output_filename)
'''
Для каждого post_id в диапазоне от 1 до 50:
Формируется URL для запроса.
Формируется имя файла для сохранения.
Вызывается асинхронная функция download_and_save_json.
'''
'''
Шаг №8: Запуск асинхронной программы:
'''
if __name__ == "__main__":
    asyncio.run(download_and_save_all_jsons())
'''
Проверяется, что скрипт был запущен как основной,
 и запускается асинхронная функция download_and_save_all_jsons с помощью asyncio.run().
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Мы также можем загружать JSON-объекты с различных открытых API, которые предоставляют данные в формате JSON. 
Например, некоторые популярные открытые API, которые предоставляют JSON-данные:

1. JSONPlaceholder: 
Это фейковый онлайн-сервис для тестирования и прототипирования, который предоставляет тестовые данные в формате JSON.

    URL: https://jsonplaceholder.typicode.com

2. OpenWeatherMap API: Предоставляет информацию о погоде в формате JSON.

    URL: https://openweathermap.org/api

3. GitHub API: Предоставляет данные о репозиториях, пользователях и других аспектах GitHub.

    URL: https://developer.github.com/v3

4. REST Countries API: Предоставляет информацию о странах в формате JSON.

    URL: https://restcountries.com

Просто выберите API, которое соответствует вашим интересам, и используйте его URL для загрузки JSON-данных.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~