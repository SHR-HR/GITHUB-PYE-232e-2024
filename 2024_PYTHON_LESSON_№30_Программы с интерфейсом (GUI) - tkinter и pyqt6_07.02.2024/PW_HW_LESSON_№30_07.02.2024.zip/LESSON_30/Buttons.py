from tkinter import *

class CancelButton(Button):
    pass