'''
Дата выполнения Практической-Работы: 19-20 - ЯНВАРЯ 2024 года.
'''
'''
Практическая работа

Курс: Разработка Web-приложений на Python, с применением Фреймворка Django
Дисциплина: Основы программирования на Python

Практическая работа №26: Сетевое программирование. Библиотеки requests и aiohttp

Выполните следующие задания:

Задание №1
а) Загрузите одиночный json – объект с сайта jsonplaceholder, используя библиотеку requests.
б) Сохраните его в файл.

'''
'''
Урок от 24.01.2024
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Выполнение задания: (а и б)
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Вариант №1.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
# Импорт библиотек
import requests
import json

# Определение функции для загрузки и сохранения JSON
def download_and_save_json(url, filename):
    try:
        # Загрузка JSON-объекта с сайта
        response = requests.get(url)
        response.raise_for_status()  # Проверка наличия ошибок при запросе

        # Сохранение JSON-объекта в файл
        with open(filename, 'w') as file:
            json.dump(response.json(), file, indent=2)

        # Вывод сообщения об успешной загрузке и сохранении
        print(f"JSON-объект успешно загружен и сохранен в файл {filename}")
    except requests.exceptions.RequestException as e:
        # Вывод сообщения об ошибке при загрузке или сохранении JSON
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")

# Указание URL и имени файла, куда сохранить JSON
json_url = "https://jsonplaceholder.typicode.com/posts/1"
output_filename = "output.json"

# Вызов функции для загрузки и сохранения JSON
download_and_save_json(json_url, output_filename)
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг 1: Импорт библиотек
'''
import requests
import json
'''
Описание:

requests: Эта библиотека используется для выполнения HTTP-запросов.
json: Эта библиотека предоставляет методы для работы с данными в формате JSON.
'''
'''
Шаг 2: Определение функции download_and_save_json
'''
def download_and_save_json(url, filename):
    try:
        # Загрузка JSON-объекта с сайта
        response = requests.get(url)
        response.raise_for_status()  # Проверка наличия ошибок при запросе

        # Сохранение JSON-объекта в файл
        with open(filename, 'w') as file:
            json.dump(response.json(), file, indent=2)

        print(f"JSON-объект успешно загружен и сохранен в файл {filename}")
    except requests.exceptions.RequestException as e:
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")
'''
Описание:

download_and_save_json: Это пользовательская функция, которая принимает два аргумента - url и filename.
requests.get(url): Этот метод выполняет GET-запрос к указанному url и возвращает объект Response.
response.raise_for_status(): Проверяет, были ли ошибки в результате запроса. Если есть, вызывает исключение HTTPError.
open(filename, 'w'): Открывает файл с указанным именем для записи.
json.dump(response.json(), file, indent=2): Записывает JSON-объект из ответа в файл с отступом в 2 пробела.
print(f"JSON-объект успешно загружен и сохранен в файл {filename}"): 
Выводит сообщение об успешной загрузке и сохранении.
'''
'''
Шаг 3: Указание URL и имени файла и вызов функции
'''
# Укажите URL и имя файла, куда сохранить JSON
json_url = "https://jsonplaceholder.typicode.com/posts/1"
output_filename = "output.json"

# Вызов функции для загрузки и сохранения JSON
download_and_save_json(json_url, output_filename)
'''
Описание:

Здесь мы устанавливаем URL и имя файла для JSON-данных.
Затем вызывается функция download_and_save_json с указанными аргументами.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Вариант №2.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
# Импорт библиотек
import requests
import json

# Определение функции для загрузки и сохранения JSON
def download_and_save_json(url, filename):
    try:
        # Загрузка JSON-объекта с сайта
        response = requests.get(url)
        response.raise_for_status()  # Проверка наличия ошибок при запросе

        # Сохранение JSON-объекта в файл
        with open(filename, 'w') as file:
            json.dump(response.json(), file, indent=2)

        # Вывод сообщения об успешной загрузке и сохранении
        print(f"JSON-объект успешно загружен и сохранен в файл {filename}")
    except requests.exceptions.RequestException as e:
        # Вывод сообщения об ошибке при загрузке или сохранении JSON
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")

# Указание URL и имени файла, куда сохранить JSON для поста
post_url = "https://jsonplaceholder.typicode.com/posts/1"
post_filename = "post_output.json"

# Вызов функции для загрузки и сохранения JSON для поста
download_and_save_json(post_url, post_filename)

# Указание URL и имени файла, куда сохранить JSON для комментариев
comments_url = "https://jsonplaceholder.typicode.com/comments?postId=1"
comments_filename = "comments_output.json"

# Вызов функции для загрузки и сохранения JSON для комментариев
download_and_save_json(comments_url, comments_filename)
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг 1: Импорт библиотек
'''
import requests
import json
'''
Описание:

requests: Эта библиотека используется для выполнения HTTP-запросов.
json: Эта библиотека предоставляет методы для работы с данными в формате JSON.
'''
'''
Шаг 2: Определение функции download_and_save_json
'''
def download_and_save_json(url, filename):
    try:
        # Загрузка JSON-объекта с сайта
        response = requests.get(url)
        response.raise_for_status()  # Проверка наличия ошибок при запросе

        # Сохранение JSON-объекта в файл
        with open(filename, 'w') as file:
            json.dump(response.json(), file, indent=2)

        print(f"JSON-объект успешно загружен и сохранен в файл {filename}")
    except requests.exceptions.RequestException as e:
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")
'''
Описание:

download_and_save_json: Это пользовательская функция, которая принимает два аргумента - url и filename.
requests.get(url): Этот метод выполняет GET-запрос к указанному url и возвращает объект Response.
response.raise_for_status(): Проверяет, были ли ошибки в результате запроса. Если есть, вызывает исключение HTTPError.
open(filename, 'w'): Открывает файл с указанным именем для записи.
json.dump(response.json(), file, indent=2): Записывает JSON-объект из ответа в файл с отступом в 2 пробела.
print(f"JSON-объект успешно загружен и сохранен в файл {filename}"): 
Выводит сообщение об успешной загрузке и сохранении.
'''
'''
Шаг 3: Указание URL и имени файла, вызов функции для поста
'''
# Укажите URL и имя файла, куда сохранить JSON для поста
post_url = "https://jsonplaceholder.typicode.com/posts/1"
post_filename = "post_output.json"

# Вызов функции для загрузки и сохранения JSON для поста
download_and_save_json(post_url, post_filename)
'''
Описание:

Здесь вы устанавливаете URL и имя файла для JSON-данных поста.
Затем вызывается функция download_and_save_json с указанными аргументами.
'''
'''
Шаг 4: Указание URL и имени файла, вызов функции для комментариев
'''
# Укажите URL и имя файла, куда сохранить JSON для комментариев
comments_url = "https://jsonplaceholder.typicode.com/comments?postId=1"
comments_filename = "comments_output.json"

# Вызов функции для загрузки и сохранения JSON для комментариев
download_and_save_json(comments_url, comments_filename)
'''
Описание:

Здесь мы устанавливаем URL и имя файла для JSON-данных комментариев.
Затем снова вызывается функция download_and_save_json с указанными аргументами.
'''
'''
В итоге, код выполняет два HTTP-запроса, загружает JSON-объекты и сохраняет их в соответствующие файлы. 
Вся логика организована внутри функции download_and_save_json, что делает код более структурированным 
и переиспользуемым.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Мы также можем загружать JSON-объекты с различных открытых API, которые предоставляют данные в формате JSON. 
Например, некоторые популярные открытые API, которые предоставляют JSON-данные:

1. JSONPlaceholder: 
Это фейковый онлайн-сервис для тестирования и прототипирования, который предоставляет тестовые данные в формате JSON.

    URL: https://jsonplaceholder.typicode.com

2. OpenWeatherMap API: Предоставляет информацию о погоде в формате JSON.

    URL: https://openweathermap.org/api

3. GitHub API: Предоставляет данные о репозиториях, пользователях и других аспектах GitHub.

    URL: https://developer.github.com/v3

4. REST Countries API: Предоставляет информацию о странах в формате JSON.

    URL: https://restcountries.com
    
Просто выберите API, которое соответствует вашим интересам, и используйте его URL для загрузки JSON-данных.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
