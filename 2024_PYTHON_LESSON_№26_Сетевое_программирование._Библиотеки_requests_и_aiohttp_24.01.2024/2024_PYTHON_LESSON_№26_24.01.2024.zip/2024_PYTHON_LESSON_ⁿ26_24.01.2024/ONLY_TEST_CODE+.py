import os
import requests
import json

def download_and_save_json_objects(url, output_folder):
    try:
        # Загрузка массива JSON-объектов с сайта
        response = requests.get(url)
        response.raise_for_status()  # Проверка наличия ошибок при запросе

        # Разбор JSON-объектов
        json_objects = response.json()

        # Создание новой папки, если она не существует
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # Цикл по каждому JSON-объекту и сохранение в отдельный файл
        for i, json_object in enumerate(json_objects):
            filename = os.path.join(output_folder, f"object_{i + 1}.json")
            with open(filename, 'w') as file:
                json.dump(json_object, file, indent=2)

            print(f"JSON-объект {i + 1} успешно сохранен в файл {filename}")

    except requests.exceptions.RequestException as e:
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")

# Укажите URL и имя новой папки для сохранения JSON-объектов
json_url = "https://jsonplaceholder.typicode.com/posts"
output_folder = "json_objects_folder"

# Вызов функции для загрузки и сохранения JSON-объектов
download_and_save_json_objects(json_url, output_folder)
