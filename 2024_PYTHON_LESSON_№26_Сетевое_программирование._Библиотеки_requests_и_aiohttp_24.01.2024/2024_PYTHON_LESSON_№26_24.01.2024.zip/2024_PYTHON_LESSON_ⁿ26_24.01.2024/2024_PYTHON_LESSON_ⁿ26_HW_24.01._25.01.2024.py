'''
Дата выполнения Домашней-Работы: 24-25 - ЯНВАРЯ 2024 года.
'''
'''
Домашняя работа

Курс: Разработка Web-приложений на Python, с применением Фреймворка Django
Дисциплина: Основы программирования на Python

Домашняя работа №26: Сетевое программирование. Библиотеки requests и aiohttp

Выполните следующие задания:

Задание №1
а) Загрузите массив json – объектов с сайта jsonplaceholder, используя библиотеку requests.
б) Сохраните циклом каждый в отдельный файл, в одну новую папку.

'''
'''
Урок от 24.01.2024
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Выполнение задания:
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import os
import requests
import json

def download_and_save_json_objects(url, output_folder):
    try:
        # Загрузка массива JSON-объектов с сайта
        response = requests.get(url)
        response.raise_for_status()  # Проверка наличия ошибок при запросе

        # Разбор JSON-объектов
        json_objects = response.json()

        # Создание новой папки, если она не существует
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # Цикл по каждому JSON-объекту и сохранение в отдельный файл
        for i, json_object in enumerate(json_objects):
            filename = os.path.join(output_folder, f"object_{i + 1}.json")
            with open(filename, 'w') as file:
                json.dump(json_object, file, indent=2)

            print(f"JSON-объект {i + 1} успешно сохранен в файл {filename}")

    except requests.exceptions.RequestException as e:
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")

# Укажите URL и имя новой папки для сохранения JSON-объектов
json_url = "https://jsonplaceholder.typicode.com/posts"
output_folder = "json_objects_folder"

# Вызов функции для загрузки и сохранения JSON-объектов
download_and_save_json_objects(json_url, output_folder)
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг 1: Импорт библиотек
'''
import os
import requests
import json
'''
Описание:

os: Эта библиотека предоставляет функционал для работы с операционной системой, в данном случае, для создания папок.
requests: Эта библиотека используется для выполнения HTTP-запросов.
json: Эта библиотека предоставляет методы для работы с данными в формате JSON.
'''
'''
Шаг 2: Определение функции download_and_save_json_objects
'''
def download_and_save_json_objects(url, output_folder):
    try:
        # Загрузка массива JSON-объектов с сайта
        response = requests.get(url)
        response.raise_for_status()  # Проверка наличия ошибок при запросе

        # Разбор JSON-объектов
        json_objects = response.json()

        # Создание новой папки, если она не существует
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # Цикл по каждому JSON-объекту и сохранение в отдельный файл
        for i, json_object in enumerate(json_objects):
            filename = os.path.join(output_folder, f"object_{i + 1}.json")
            with open(filename, 'w') as file:
                json.dump(json_object, file, indent=2)

            print(f"JSON-объект {i + 1} успешно сохранен в файл {filename}")

    except requests.exceptions.RequestException as e:
        print(f"Произошла ошибка при загрузке или сохранении JSON: {e}")
'''
Описание:

download_and_save_json_objects: Это пользовательская функция, которая принимает два аргумента - url и output_folder.
requests.get(url): Этот метод выполняет GET-запрос к указанному url и возвращает объект Response.
response.raise_for_status(): Проверяет, были ли ошибки в результате запроса. Если есть, вызывает исключение HTTPError.
json_objects = response.json(): Разбирает JSON-объекты из ответа.
os.makedirs(output_folder): Создает новую папку, если она не существует.
enumerate(json_objects): Возвращает индекс и текущий элемент из списка JSON-объектов.
os.path.join(output_folder, f"object_{i + 1}.json"): Формирует полный путь к файлу с учетом созданной папки и 
индекса объекта.
json.dump(json_object, file, indent=2): Записывает JSON-объект в файл с отступом в 2 пробела.
print(f"JSON-объект {i + 1} успешно сохранен в файл {filename}"): Выводит сообщение об успешном сохранении.
'''
'''
Шаг 3: Указание URL и имени новой папки, вызов функции
'''
# Укажите URL и имя новой папки для сохранения JSON-объектов
json_url = "https://jsonplaceholder.typicode.com/posts"
output_folder = "json_objects_folder"

# Вызов функции для загрузки и сохранения JSON-объектов
download_and_save_json_objects(json_url, output_folder)
'''
Описание:

Здесь мы устанавливаем URL и имя новой папки для JSON-данных.
Затем вызывается функция download_and_save_json_objects с указанными аргументами.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Да, так-же мы можем использовать любой из предложенных сервисов для загрузки массива JSON-объектов.
Все в точности как и в практической работе №26.

Примеры URL для загрузки данных:

1. JSONPlaceholder:

    URL для постов: https://jsonplaceholder.typicode.com/posts
    URL для комментариев: https://jsonplaceholder.typicode.com/comments
    Используем любой из этих URL в зависимости от ваших потребностей.

2. OpenWeatherMap API:

    Пример URL для получения данных о погоде 
    в Лондоне: https://api.openweathermap.org/data/2.5/weather?q=London&appid=YOUR_API_KEY
    Необходимо заменить YOUR_API_KEY на необходимый ключ API, полученный после регистрации на сайте OpenWeatherMap.
    
3. GitHub API:

    Документация GitHub API: https://developer.github.com/v3
    Мы можем использовать различные эндпойнты API в зависимости от того, какие данные нужны.
    
4. REST Countries API:

    Пример URL для получения информации о странах: https://restcountries.com/v3.1/all
    Этот URL предоставит информацию о всех странах. 
    Мы также можем использовать другие эндпойнты для более конкретных запросов.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~




