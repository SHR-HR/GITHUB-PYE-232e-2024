# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
''''
Дата выполнения Домашней работы: 08-09 - ЯНВАРЯ 2024 года.
''''
'''
Курс: Разработка Web-приложений на Python, с применением Фреймворка Django
Дисциплина: Основы HTML и CSS !!! НО НАПИСАЛ Я КОД В PYCHARM - на PYTHON
'''
'''
Урок от 08.01.2024
Домашнее задание № 1 : Введение в Веб разработку
'''
'''
Выполните следующие задания:
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
1. Установить Visual Studio Code.
2. Создать html файл с помощью VSCode.
3. Написать в html файле свои имя и фамилию.
4. Открыть в браузере с инструментами разработчика.
5. Сделать скриншот и отправить его вместе с вашим html файлом.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Скриншоты можно делать с помощью встроенного приложения Ножницы или с помощью бесплатной программы LightShot.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Выполнение задания:
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Вариант - более правильный наверное. (Написанный на Python)
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import re
import sqlite3
import html
import webbrowser

# Создаем подключение к базе данных (или создаем базу данных, если ее нет)
conn = sqlite3.connect('names_database.db')
cursor = conn.cursor()

# Создаем таблицу, если ее нет
cursor.execute('''
    CREATE TABLE IF NOT EXISTS names (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT,
        last_name TEXT
    )
''')
conn.commit()

def validate_name(name):
    # Проверка, что имя состоит только из букв, как в русском, так и в английском алфавите
    return re.match("^[а-яА-Яa-zA-Z]+$", name) is not None

# Получаем имя от пользователя с проверкой ввода
name = input("Введите ваше имя: ")
while not validate_name(name):
    print("Ошибка: Имя должно состоять только из букв русского или английского алфавита.")
    name = input("Введите ваше имя: ")

# Получаем фамилию от пользователя с проверкой ввода
surname = input("Введите вашу фамилию: ")
while not validate_name(surname):
    print("Ошибка: Фамилия должна состоять только из букв русского или английского алфавита.")
    surname = input("Введите вашу фамилию: ")

# Записываем введенные данные в базу данных
cursor.execute('INSERT INTO names (first_name, last_name) VALUES (?, ?)', (name, surname))
conn.commit()

# Записываем введенные данные в HTML-файл
with open('index.html', 'w', encoding='utf-8') as file:
    # Записываем начальный HTML-код
    file.write('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Имя и Фамилия</title>
</head>
<body>
''')

    # Записываем введенные данные в HTML-файл с разными стилями
    file.write(f'    <h3>{html.escape(name)}</h3>\n')  # Стандартное отображение (для наглядности чуть уменьшил шрифт)
    file.write(f'    <h2><i>{html.escape(name)}</i></h2>\n')  # Курсивное отображение (для наглядности чуть уменьшил шрифт)
    file.write(f'    <h1><b>{html.escape(name)}</b></h1>\n')  # Жирное отображение

    file.write(f'    <h3>{html.escape(surname)}</h3>\n')  # Стандартное отображение (для наглядности чуть уменьшил шрифт)
    file.write(f'    <h2><i>{html.escape(surname)}</i></h2>\n')  # Курсивное отображение (для наглядности чуть уменьшил шрифт)
    file.write(f'    <h1><b>{html.escape(surname)}</b></h1>\n')  # Жирное отображение

    # Добавляем рамку для JPG-изображения
    file.write('    <div style="border: 1px solid #ccc; padding: 10px; margin-top: 20px; width: 500px; height: 500px;">\n')
    file.write('        <img src="https://sun1-13.userapi.com/s/v1/if1/ygP2SHKIEpSAcXSnjPOnyo_29b2oYdOwC-tYTq_g_pxbMtjq6LFPpYHALe4I2vpHCNC4RmWX.jpg?size=200x200&quality=96&crop=290,94,382,382&ava=1" style="width: 100%; height: 100%;">\n')
    file.write('    </div>\n')

    # Добавляем рамку для GIF-изображения
    file.write('    <div style="border: 1px solid #ccc; padding: 10px; margin-top: 20px; width: 500px; height: 500px;">\n')
    file.write('        <img src="https://cdn.humoraf.ru/wp-content/uploads/2019/04/ponedelnik-gifki-humoraf-53.gif" alt="GIF Картинка" style="width: 100%; height: 100%;">\n')
    file.write('    </div>\n')

    # Записываем закрывающий HTML-код
    file.write('''
</body>
</html>
''')

print("HTML-файл создан успешно.")

# Открываем HTML-файл в браузере
webbrowser.open('index.html', new=2)

# Закрываем соединение с базой данных
conn.close()
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг №1: Подключение к базе данных

Название функции/команды: sqlite3.connect('names_database.db')

Пример:
'''
conn = sqlite3.connect('names_database.db')
'''
Описание:
Эта строка кода создает подключение к базе данных SQLite с именем "names_database.db" или открывает уже существующую 
базу данных с таким именем. Если базы данных нет, она будет создана. Объект conn представляет собой соединение
с базой данных.
'''
'''
Шаг №2: Создание таблицы в базе данных

Название функции/команды: cursor.execute('''CREATE TABLE IF NOT EXISTS names (id INTEGER PRIMARY KEY AUTOINCREMENT,
first_name TEXT, last_name TEXT)''')

Пример:
'''
cursor.execute('''
    CREATE TABLE IF NOT EXISTS names (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT,
        last_name TEXT
    )
''')
'''
Описание:
Эта строка кода создает таблицу "names" в базе данных с тремя полями: "id" (целочисленный идентификатор,
автоматически увеличиваемый), "first_name" и "last_name" (текстовые поля для хранения имени и фамилии соответственно).
'''
'''
Шаг №3: Валидация имени

Название функции/команды: re.match("^[а-яА-Яa-zA-Z]+$", name)

Пример:
'''
return re.match("^[а-яА-Яa-zA-Z]+$", name) is not None
'''
Описание:
Эта функция validate_name использует регулярное выражение для проверки того, что переданное имя состоит только из
букв русского или английского алфавита. Возвращает True, если условие выполняется, и False в противном случае.
'''
'''
Шаг №4: Запись данных в базу данных

Название функции/команды: cursor.execute('INSERT INTO names (first_name, last_name) VALUES (?, ?)', (name, surname))

Пример:
'''
cursor.execute('INSERT INTO names (first_name, last_name) VALUES (?, ?)', (name, surname))
'''
Описание:
Эта строка кода вставляет введенные пользователем имя и фамилию в таблицу "names" базы данных.
'''
'''
Шаг №5: Запись данных в HTML-файл

Название функции/команды: with open('index.html', 'w', encoding='utf-8') as file:

Пример:
'''
with open('index.html', 'w', encoding='utf-8') as file:
'''
Описание:
Этот блок кода открывает файл 'index.html' для записи в кодировке UTF-8. Файл будет использоваться для 
создания HTML-страницы.
'''
'''
Шаг №6: Запись HTML-кода в файл

Название функции/команды: file.write(...)

Пример:
'''
file.write('    <h3>{html.escape(name)}</h3>\n')
'''
Описание:
Этот блок кода записывает различные версии имени и фамилии в HTML-файл с разными стилями 
(стандартное, курсивное, жирное) и добавляет рамки для JPG и GIF изображений с соответствующими ссылками.
'''
'''
Шаг №7: Закрытие HTML-файла

Название функции/команды: file.write('...</body></html>')

Пример:
'''
file.write('''
</body>
</html>
''')
'''
Описание:
Эта строка кода закрывает HTML-код в файле после записи данных и завершает создание HTML-страницы.
'''
'''
Шаг №8: Открытие HTML-файла в браузере

Название функции/команды: webbrowser.open('index.html', new=2)

Пример:
'''
webbrowser.open('index.html', new=2)
'''
Описание:
Эта строка кода открывает созданный HTML-файл в браузере. Аргумент new=2 гарантирует, 
что файл открывается в новой вкладке.
'''
'''
Шаг №9: Закрытие соединения с базой данных

Название функции/команды: conn.close()

Пример:
'''
conn.close()
'''
Описание:
Эта строка кода закрывает соединение с базой данных после выполнения всех операций.
'''

'''
Как итог, этот код выполняет следующие функции:

1. Устанавливает соединение с базой данных SQLite, создает таблицу "names" и проверяет наличие или создает базу данных.
2. Вводит имя и фамилию от пользователя, проверяет их на корректность (только буквы русского или английского алфавита).
3. Записывает введенные данные в базу данных и создает HTML-файл с разными стилями отображения имени и фамилии,
а также добавляет рамки для JPG и GIF изображений.
4. Открывает созданный HTML-файл в браузере.
5. Закрывает соединение с базой данных.
'''

