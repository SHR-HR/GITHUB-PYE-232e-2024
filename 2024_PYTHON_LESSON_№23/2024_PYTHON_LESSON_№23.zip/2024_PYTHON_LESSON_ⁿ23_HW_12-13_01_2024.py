# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
''''
Дата выполнения Домашней-Работы: 12-13 - ЯНВАРЯ 2024 года.
''''
'''
Домашнее задание

Курс: Разработка Web-приложений на Python, с применением Фреймворка Django

Дисциплина: Основы программирования на Python

Домашнее задание № 23 : Многопоточное, асинхронное и мультипроцессорное программирование. GIL

Выполните следующие задания:

Задание №1

а) Напишите функцию, которая будет создавать файл, с задержкой 1 секунду.
б) Запустите циклом 100 таких функций, а также замерьте время.
в) Добавьте функционал многопоточного запуска, с замером времени.

** В качестве ответа прикрепить скрин и ссылку на github.
'''
'''
Урок от 12.01.2024
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Выполнение задания:
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import threading
import time


# Шаг 1: Написание функции для создания файла с задержкой
def create_file_with_delay(file_number):
    time.sleep(1)  # Задержка в 1 секунду
    file_name = f"file_{file_number}.txt"

    with open(file_name, "w") as file:
        file.write("This is a sample file.")

    print(f"File '{file_name}' created.")


# Шаг 2: Запуск циклом 100 функций и замер времени
start_time = time.time()

for i in range(1, 101):
    create_file_with_delay(i)

end_time = time.time()

print("Time taken without threading: {:.2f} seconds".format(end_time - start_time))

# Шаг 3: Добавление функционала многопоточного запуска и замер времени
start_time = time.time()

threads = []
for i in range(1, 101):
    thread = threading.Thread(target=create_file_with_delay, args=(i,))
    threads.append(thread)
    thread.start()

# Ожидание завершения всех потоков
for thread in threads:
    thread.join()

end_time = time.time()

print("Time taken with threading: {:.2f} seconds".format(end_time - start_time))
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг 1: Импорт библиотек
'''
import threading
import time
'''
Описание: 
В этом шаге импортируются две библиотеки - threading для работы с многопоточностью и time для работы с временем.
'''
'''
Шаг 2: Определение функции для создания файла с задержкой
'''
def create_file_with_delay(file_number):
    time.sleep(1)  # Задержка в 1 секунду
    file_name = f"file_{file_number}.txt"

    with open(file_name, "w") as file:
        file.write("This is a sample file.")

    print(f"File '{file_name}' created.")
'''
Описание: 
Эта функция create_file_with_delay принимает file_number в качестве аргумента, добавляет задержку в 1 секунду 
с использованием time.sleep(1), затем создает файл с именем, содержащим номер, и записывает в него текст.
В конце функция выводит сообщение о создании файла.
'''
'''
Шаг 3: Запуск циклом 100 функций и замер времени без использования многопоточности
'''
start_time = time.time()

for i in range(1, 101):
    create_file_with_delay(i)

end_time = time.time()

print("Time taken without threading: {:.2f} seconds".format(end_time - start_time))
'''
Описание:
В этом шаге создается цикл, который запускает функцию create_file_with_delay 100 раз для создания файлов с задержкой.
Время начала измеряется с использованием time.time(), а затем выводится время выполнения после завершения цикла.
'''
'''
Шаг 4: Добавление функционала многопоточного запуска и замер времени
'''
start_time = time.time()

threads = []
for i in range(1, 101):
    thread = threading.Thread(target=create_file_with_delay, args=(i,))
    threads.append(thread)
    thread.start()

# Ожидание завершения всех потоков
for thread in threads:
    thread.join()

end_time = time.time()

print("Time taken with threading: {:.2f} seconds".format(end_time - start_time))
'''
Описание:
В этом шаге создается новый цикл, который использует многопоточность. 
Создаются 100 потоков (threads), каждый из которых запускает функцию create_file_with_delay с уникальным file_number. 
Затем выполняется ожидание завершения всех потоков с использованием thread.join(). 
Время выполнения снова измеряется и выводится.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
ЕЩЕ ВАРИАНТ
'''
import concurrent.futures
import asyncio
import time

def create_file_with_delay_thread(file_number):
    time.sleep(1)
    file_name = f"thread_file_{file_number}.txt"

    with open(file_name, "w") as file:
        file.write("This is a sample file.")

    print(f"Thread File '{file_name}' created.")

async def create_file_with_delay_asyncio(file_number):
    await asyncio.sleep(1)
    file_name = f"asyncio_file_{file_number}.txt"

    with open(file_name, "w") as file:
        file.write("This is a sample file.")

    print(f"AsyncIO File '{file_name}' created.")

async def main():
    # Используем ThreadPoolExecutor для многопоточности
    with concurrent.futures.ThreadPoolExecutor() as executor:
        executor.map(create_file_with_delay_thread, range(1, 51))

    # Используем asyncio для асинхронного выполнения
    tasks = [create_file_with_delay_asyncio(i) for i in range(51, 101)]
    await asyncio.gather(*tasks)

start_time = time.time()
asyncio.run(main())
end_time = time.time()

print("Time taken with ThreadPoolExecutor and asyncio: {:.2f} seconds".format(end_time - start_time))
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Импорт библиотек само собой
'''
'''
Шаг 1:
'''
def create_file_with_delay_thread(file_number):
    time.sleep(1)
    file_name = f"thread_file_{file_number}.txt"

    with open(file_name, "w") as file:
        file.write("This is a sample file.")

    print(f"Thread File '{file_name}' created.")
'''
Описание:

Эта функция create_file_with_delay_thread представляет собой синхронную функцию,
которая создает файл с использованием задержки в 1 секунду. Она принимает аргумент file_number,
который используется для создания уникального имени файла. Функция использует time.sleep(1),
чтобы создать задержку в 1 секунду перед созданием файла. Затем она открывает файл с именем, 
сформированным на основе file_number, и записывает в него строку. Наконец, выводится сообщение в 
консоль о создании файла.
'''
'''
Шаг 2:
'''
async def create_file_with_delay_asyncio(file_number):
    await asyncio.sleep(1)
    file_name = f"asyncio_file_{file_number}.txt"

    with open(file_name, "w") as file:
        file.write("This is a sample file.")

    print(f"AsyncIO File '{file_name}' created.")
'''
Описание:

Эта функция create_file_with_delay_asyncio - это асинхронная функция, использующая async/await, 
чтобы создать файл с задержкой в 1 секунду. Она аналогична предыдущей функции, но с использованием асинхронных 
возможностей. Она также принимает аргумент file_number, формирует уникальное имя файла, создает задержку с 
использованием await asyncio.sleep(1), и затем создает и записывает файл, выводя сообщение о создании в консоль.
'''
'''
Шаг 3:
'''
async def main():
    # Используем ThreadPoolExecutor для многопоточности
    with concurrent.futures.ThreadPoolExecutor() as executor:
        executor.map(create_file_with_delay_thread, range(1, 51))

    # Используем asyncio для асинхронного выполнения
    tasks = [create_file_with_delay_asyncio(i) for i in range(51, 101)]
    await asyncio.gather(*tasks)
'''
Описание:

Эта функция main является точкой входа для выполнения обоих подходов (многопоточного и асинхронного).
Внутри main сначала используется ThreadPoolExecutor для запуска функции create_file_with_delay_thread 50 раз в
многопоточной среде. Затем используется asyncio для выполнения функции create_file_with_delay_asyncio еще 50 раз в
асинхронной среде. Весь код выполняется асинхронно, и функция main ожидает завершения всех задач, 
используя await asyncio.gather(*tasks).
'''
start_time = time.time()
asyncio.run(main())
end_time = time.time()

print("Time taken with ThreadPoolExecutor and asyncio: {:.2f} seconds".format(end_time - start_time))
'''
Описание:

Здесь вычисляется и выводится общее время выполнения обоих подходов с использованием многопоточности и асинхронности.
'''
