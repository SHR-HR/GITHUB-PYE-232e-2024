# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
''''
Дата выполнения Практической-Работы: 12-13 - ЯНВАРЯ 2024 года.
''''
'''
Практическая работа

Курс: Разработка Web-приложений на Python, с применением Фреймворка Django

Дисциплина: Основы программирования на Python

Практическая работа №23: Многопоточное, асинхронное и мультипроцессорное программирование. GIL

Выполните следующие задания:

Задание №1
а) Напишите функцию, которая будет складывать два числа, и спустя 1 секунду задержки возвращать результат.
б) Запустите циклом 100 таких функций, а также замерьте время.
в) Добавьте функционал многопоточного запуска, с замером времени.
'''
'''
Урок от 12.01.2024
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Выполнение задания:
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import threading
import time

# Задание №1

# a) Функция для сложения двух чисел с задержкой в 1 секунду
def add_numbers(x, y):
    time.sleep(1)
    return x + y

# b) Запуск циклом 100 таких функций и замер времени
start_time = time.time()

results = []
for _ in range(100):
    result = add_numbers(3, 4)  # Пример: сложение чисел 3 и 4
    results.append(result)

end_time = time.time()
print("Time taken without threading: {:.2f} seconds".format(end_time - start_time))

# c) Функционал многопоточного запуска с замером времени
start_time = time.time()

results_mt = []
threads = []

def worker():
    result = add_numbers(3, 4)
    results_mt.append(result)

for _ in range(100):
    thread = threading.Thread(target=worker)
    thread.start()
    threads.append(thread)

# Ожидание завершения всех потоков
for thread in threads:
    thread.join()

end_time = time.time()
print("Time taken with threading: {:.2f} seconds".format(end_time - start_time))
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Далее более подробно:
'''
'''
Для начала импортируем все то что нам нужно:
'''
import threading
import time
'''
Шаг 1: Функция add_numbers
'''
def add_numbers(x, y):
    time.sleep(1)
    return x + y
'''
Описание:

Название функции: add_numbers.

Пример кода:

def add_numbers(x, y):: Определяет функцию с именем add_numbers, принимающую два аргумента x и y.
time.sleep(1): Вызывает функцию sleep из модуля time, приостанавливая выполнение программы на 1 секунду.
Это эмулирует задержку в функции.
return x + y: Возвращает сумму x и y.
Более подробное описание:

Функция add_numbers принимает два аргумента x и y и добавляет их. 
Однако, перед возвратом результата, функция "засыпает" на 1 секунду с использованием time.sleep(1).
Это добавляет задержку к выполнению функции, чтобы сделать ее более реалистичной для примера многопоточности.
'''
'''
Шаг 2: Блок кода для выполнения без использования потоков
'''
# b) Запуск циклом 100 таких функций и замер времени
start_time = time.time()

results = []
for _ in range(100):
    result = add_numbers(3, 4)  # Пример: сложение чисел 3 и 4
    results.append(result)

end_time = time.time()
print("Time taken without threading: {:.2f} seconds".format(end_time - start_time))
'''
Описание:

Пример кода:

start_time = time.time(): Записывает текущее время в переменную start_time.
results = []: Создает пустой список для хранения результатов функций.
for _ in range(100):: Начинает цикл, который выполняется 100 раз.
result = add_numbers(3, 4): Вызывает функцию add_numbers с аргументами 3 и 4 (пример сложения чисел) и 
сохраняет результат в переменную result.
results.append(result): Добавляет результат в список results.
end_time = time.time(): Записывает текущее время в переменную end_time.
print("Time taken without threading: {:.2f} seconds".format(end_time - start_time)): Выводит в консоль время,
затраченное на выполнение цикла без использования потоков.

Более подробное описание:

В этом блоке кода мы запускаем цикл, который 100 раз вызывает функцию add_numbers с аргументами 3 и 4.
Результат каждого вызова добавляется в список results. Затем мы замеряем время, затраченное на выполнение цикла,
и выводим его в консоль.
'''
'''
Шаг 3: Блок кода для выполнения с использованием потоков
'''
# c) Функционал многопоточного запуска с замером времени
start_time = time.time()

results_mt = []
threads = []

def worker():
    result = add_numbers(3, 4)
    results_mt.append(result)

for _ in range(100):
    thread = threading.Thread(target=worker)
    thread.start()
    threads.append(thread)

# Ожидание завершения всех потоков
for thread in threads:
    thread.join()

end_time = time.time()
print("Time taken with threading: {:.2f} seconds".format(end_time - start_time))
'''
Описание:

Пример кода:

start_time = time.time(): Записывает текущее время в переменную start_time.
results_mt = []: Создает пустой список для хранения результатов функций с использованием потоков.
threads = []: Создает пустой список для хранения объектов потоков.
def worker():: Определяет функцию worker, которая вызывает add_numbers и добавляет результат в список results_mt.
for _ in range(100):: Начинает цикл, который выполняется 100 раз.
thread = threading.Thread(target=worker): Создает объект потока, используя функцию worker в качестве цели.
thread.start(): Запускает поток.
threads.append(thread): Добавляет объект потока в список.
for thread in threads: и thread.join(): Ожидает завершения всех потоков.
end_time = time.time(): Записывает текущее время в переменную end_time.
print("Time taken with threading: {:.2f} seconds".format(end_time - start_time)): Выводит в консоль время,
затраченное на выполнение цикла с использованием потоков.

Более подробное описание:

В этом блоке кода мы используем многопоточность для выполнения функции add_numbers параллельно в 100 потоках.
Каждый поток вызывает функцию worker, которая в свою очередь вызывает add_numbers и добавляет результат 
в список results_mt. Мы замеряем время, затраченное на выполнение этого блока кода, и выводим его в консоль.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Возможные альтернативные варианты
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Вариант 1: Использование concurrent.futures для многопоточности
'''
import concurrent.futures
import time

def add_numbers(x, y):
    time.sleep(1)
    return x + y

def worker(_):
    result = add_numbers(3, 4)
    return result

# Используем ThreadPoolExecutor для многопоточности
start_time = time.time()
with concurrent.futures.ThreadPoolExecutor() as executor:
    results_mt = list(executor.map(worker, range(100)))

end_time = time.time()
print("Time taken with concurrent.futures: {:.2f} seconds".format(end_time - start_time))
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
В этом варианте используется модуль concurrent.futures, который предоставляет высокоуровневый интерфейс для работы
с потоками и процессами. Мы используем ThreadPoolExecutor для создания пула потоков и функцию executor.map для
многопоточного выполнения задач.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг 1: Функция add_numbers
'''
def add_numbers(x, y):
    time.sleep(1)
    return x + y
'''
Описание:

Название функции: add_numbers.

Пример кода:
def add_numbers(x, y):: Определяет функцию с именем add_numbers, принимающую два аргумента x и y.
time.sleep(1): Вызывает функцию sleep из модуля time, приостанавливая выполнение программы на 1 секунду. 
Это эмулирует задержку в функции.
return x + y: Возвращает сумму x и y.

Более подробное описание:

Функция add_numbers принимает два аргумента x и y и добавляет их. 
Однако, перед возвратом результата, функция "засыпает" на 1 секунду с использованием time.sleep(1). 
Это добавляет задержку к выполнению функции, чтобы сделать ее более реалистичной для примера многопоточности.
'''
'''
Шаг 2: Блок кода с использованием concurrent.futures
'''
# Используем ThreadPoolExecutor для многопоточности
start_time = time.time()
with concurrent.futures.ThreadPoolExecutor() as executor:
    results_mt = list(executor.map(worker, range(100)))

end_time = time.time()
print("Time taken with concurrent.futures: {:.2f} seconds".format(end_time - start_time))
'''
Описание:

Пример кода:
start_time = time.time(): Записывает текущее время в переменную start_time.
with concurrent.futures.ThreadPoolExecutor() as executor:: Создает ThreadPoolExecutor в контексте.
results_mt = list(executor.map(worker, range(100))): Запускает функцию worker в 100 потоках и получает результаты 
с использованием executor.map.
end_time = time.time(): Записывает текущее время в переменную end_time.
print("Time taken with concurrent.futures: {:.2f} seconds".format(end_time - start_time)): Выводит в консоль время,
затраченное на выполнение кода с использованием ThreadPoolExecutor.

Более подробное описание:

Мы используем ThreadPoolExecutor из concurrent.futures для создания пула потоков. 
В контексте блока with мы вызываем функцию worker в 100 потоках с использованием executor.map. 
Этот метод ожидает завершения всех потоков и возвращает результаты в виде списка. 
Затем мы замеряем время выполнения этого блока кода и выводим результат в консоль.
'''
'''
В итоге, код в Варианте 1 демонстрирует использование ThreadPoolExecutor для параллельного выполнения функции в
нескольких потоках, что может быть полезным при выполнении множества схожих задач.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Вариант 2: Использование asyncio для асинхронного выполнения
'''
import asyncio
import time

async def add_numbers(x, y):
    await asyncio.sleep(1)
    return x + y

async def worker():
    result = await add_numbers(3, 4)
    return result

# Используем asyncio для асинхронного выполнения
start_time = time.time()

# Создаем новый цикл событий, если его нет
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

# Запускаем асинхронные задачи
results_mt = loop.run_until_complete(asyncio.gather(*(worker() for _ in range(100))))

end_time = time.time()

print("Time taken with asyncio: {:.2f} seconds".format(end_time - start_time))
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг 1: Определение асинхронных функций
'''
async def add_numbers(x, y):
    await asyncio.sleep(1)
    return x + y

async def worker():
    result = await add_numbers(3, 4)
    return result
'''
Описание:
add_numbers: Асинхронная функция, принимающая два аргумента x и y. 
Она приостанавливает выполнение на 1 секунду с помощью await asyncio.sleep(1) и затем возвращает сумму x и y.
worker: Еще одна асинхронная функция, вызывающая add_numbers с аргументами 3 и 4. 
Она также использует await, чтобы ждать завершения выполнения add_numbers и затем возвращает результат.
'''
'''
Шаг 2: Использование asyncio для асинхронного выполнения
'''
start_time = time.time()
loop = asyncio.get_event_loop()
tasks = [worker() for _ in range(100)]
results_mt = loop.run_until_complete(asyncio.gather(*tasks))
end_time = time.time()
'''
Описание:
start_time = time.time(): Записывает текущее время перед началом выполнения асинхронного кода.
loop = asyncio.get_event_loop(): Получает экземпляр цикла событий asyncio.
tasks = [worker() for _ in range(100)]: Создает список асинхронных задач, 
каждая из которых представляет собой вызов функции worker().
results_mt = loop.run_until_complete(asyncio.gather(*tasks)): Запускает выполнение всех асинхронных 
задач с помощью asyncio.gather() и блокирует выполнение до их завершения. 
Результаты сохраняются в results_mt.
end_time = time.time(): Записывает текущее время после завершения выполнения асинхронного кода.
'''
'''
Шаг 3: Вывод результатов
'''
print("Time taken with asyncio: {:.2f} seconds".format(end_time - start_time))
'''
Описание:
print("Time taken with asyncio: {:.2f} seconds".format(end_time - start_time)): Выводит в консоль время, 
затраченное на выполнение всех асинхронных задач. В данном случае, это время выполнения 100 вызовов функции worker().
'''
'''
Более подробное описание:

Код использует асинхронные функции для эмуляции параллельного выполнения асинхронных задач. 
В цикле for создается список из 100 вызовов worker(). Затем с помощью asyncio.gather() 
запускаются все эти задачи параллельно, и код блокируется до их завершения. Время выполнения замеряется 
с использованием time.time().
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Можно прям и по этапно ("пошагово") - т.е. - а), б), в).
'''

'''
Шаг а): Напишите функцию, складывающую два числа с задержкой в 1 секунду
'''
import asyncio

async def add_numbers(x, y):
    await asyncio.sleep(1)  # Асинхронная задержка на 1 секунду
    return x + y
'''
Описание:

add_numbers: Асинхронная функция, принимающая два аргумента x и y.
Она приостанавливает выполнение на 1 секунду с помощью await asyncio.sleep(1) и затем возвращает сумму x и y.
'''

'''
Шаг 1б: Запустите циклом 100 таких функций, а также замерьте время
'''
import asyncio
import time

# Определение асинхронных функций
async def add_numbers(x, y):
    await asyncio.sleep(1)
    return x + y

async def worker():
    result = await add_numbers(3, 4)
    return result

# Использование asyncio для асинхронного выполнения
start_time = time.time()
loop = asyncio.get_event_loop()
tasks = [worker() for _ in range(100)]
results_mt = loop.run_until_complete(asyncio.gather(*tasks))
end_time = time.time()

print("Time taken with asyncio: {:.2f} seconds".format(end_time - start_time))
'''
Описание:

start_time = time.time(): Записывает текущее время перед началом выполнения асинхронного кода.
loop = asyncio.get_event_loop(): Получает экземпляр цикла событий asyncio.
tasks = [worker() for _ in range(100)]: Создает список асинхронных задач, каждая из которых представляет 
собой вызов функции worker().
results_mt = loop.run_until_complete(asyncio.gather(*tasks)): Запускает выполнение всех асинхронных задач 
с помощью asyncio.gather() и блокирует выполнение до их завершения. Результаты сохраняются в results_mt.
end_time = time.time(): Записывает текущее время после завершения выполнения асинхронного кода.
'''

'''
Шаг 1в: Добавьте функционал многопоточного запуска, с замером времени
'''
import concurrent.futures
import time

# Определение функции
def add_numbers(x, y):
    time.sleep(1)
    return x + y

# Использование ThreadPoolExecutor для многопоточности
start_time = time.time()
with concurrent.futures.ThreadPoolExecutor() as executor:
    results_mt = list(executor.map(add_numbers, [3] * 100, [4] * 100))
end_time = time.time()

print("Time taken with concurrent.futures: {:.2f} seconds".format(end_time - start_time))
'''
Описание:

start_time = time.time(): Записывает текущее время перед началом выполнения кода с использованием ThreadPoolExecutor.
with concurrent.futures.ThreadPoolExecutor() as executor: Создает ThreadPoolExecutor для многопоточности.
results_mt = list(executor.map(add_numbers, [3] * 100, [4] * 100)): Запускает выполнение функции add_numbers в 
нескольких потоках с помощью executor.map() и сохраняет результаты в results_mt.
end_time = time.time(): Записывает текущее время после завершения выполнения кода с использованием ThreadPoolExecutor.
'''


